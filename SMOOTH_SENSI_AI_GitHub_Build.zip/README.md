# SMOOTH SENSI AI (Android prototype)

## Included
- Native Kotlin Android starter project
- Device information dashboard (manufacturer/model, Android version, resolution, reported refresh rate, RAM)
- Editable Free Fire MAX sensitivity profile (six values, 0–200)
- User-guided training observation analyzer with cautious adjustment suggestions
- Attempts to launch Free Fire MAX if installed

## Important limitations
- This prototype does not inspect Free Fire MAX's private settings, game memory, or internal files.
- Current in-game sensitivity values must be entered/confirmed by the user. Android apps cannot safely assume they can read another app's private settings.
- Screen capture / live visual analysis is not included yet. It requires explicit Android MediaProjection consent and careful privacy design.
- No guarantee of headshots; recommendations are experimental practice starting points.
- No game-file modification, input injection, macros, or anti-cheat bypass.

## Build
1. Install Android Studio (recent stable version) on a computer.
2. Open this project folder in Android Studio.
3. Let Gradle sync complete.
4. Connect your Android phone with USB debugging enabled, or use an emulator.
5. Press Run.

To make a release APK: Build > Build Bundle(s) / APK(s) > Build APK(s).

Package: `com.smooth.sensiai`
Minimum Android: 8.0 (API 26)

## GitHub Actions cloud build
This project includes `.github/workflows/android.yml`.
Upload the extracted project files to a GitHub repository (keep the `.github` folder).
Then open the repository's Actions tab and run "Build SMOOTH SENSI AI APK", or push to `main`.
When the workflow completes, open the run and download the `SMOOTH-SENSI-AI-debug-apk` artifact.
